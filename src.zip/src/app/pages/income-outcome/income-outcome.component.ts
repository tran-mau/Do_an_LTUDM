import { Component } from '@angular/core';

@Component({
  selector: 'app-income-outcome',
  imports: [],
  templateUrl: './income-outcome.component.html',
  styleUrl: './income-outcome.component.css'
})
export class IncomeOutcomeComponent {

}
