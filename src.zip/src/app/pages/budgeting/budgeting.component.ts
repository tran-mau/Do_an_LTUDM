import { Component } from '@angular/core';

@Component({
  selector: 'app-budgeting',
  imports: [],
  templateUrl: './budgeting.component.html',
  styleUrl: './budgeting.component.css'
})
export class BudgetingComponent {

}
