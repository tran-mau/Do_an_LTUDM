import { Component } from '@angular/core';

@Component({
  selector: 'app-logout-section',
  imports: [],
  templateUrl: './logout-section.component.html',
  styleUrl: './logout-section.component.css'
})
export class LogoutSectionComponent {

}
