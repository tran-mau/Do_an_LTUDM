import { Component } from '@angular/core';

@Component({
  selector: 'app-interface-section',
  imports: [],
  templateUrl: './interface-section.component.html',
  styleUrl: './interface-section.component.css'
})
export class InterfaceSectionComponent {

}
